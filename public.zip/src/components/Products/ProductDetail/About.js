import React from 'react';

function About() {
    return (
        <div className="card-body">
            <h3>Where can I get some?</h3>
            <ul>
                <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                <li>Phasellus accumsan orci sit amet orci malesuada tristique.</li>
                <li>Morbi varius odio et lorem ornare, auctor rutrum est rhoncus.</li>
                <li>Vivamus consequat tortor eu consequat eleifend.</li>
            </ul>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse aliquet sem in erat volutpat, nec sollicitudin erat varius. Sed feugiat, leo varius facilisis sagittis, lorem magna cursus tortor, molestie venenatis odio nunc quis eros.Morbi volutpat dui vitae efficitur posuere.</p>
            <p>Donec ut libero imperdiet, eleifend ipsum vitae, laoreet nisl. Morbi volutpat dui vitae efficitur posuere. Pellentesque mi libero, dapibus ut tellus eu, volutpat viverra magna. Phasellus vitae erat porta, condimentum enim ac, luctus dui. Fusce dignissim, neque quis aliquet posuere, ante tortor lobortis eros, et facilisis dolor ipsum malesuada ante.</p>
        </div>
    )
}
export default About;