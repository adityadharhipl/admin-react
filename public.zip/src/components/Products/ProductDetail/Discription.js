import React from 'react';

function Discription() {
    return (
        <div className="card-body">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse aliquet sem in erat volutpat, nec sollicitudin erat varius. Sed feugiat, leo varius facilisis sagittis, lorem magna cursus tortor, molestie venenatis odio nunc quis eros.Morbi volutpat dui vitae efficitur posuere.</p>
            <p>Donec ut libero imperdiet, eleifend ipsum vitae, laoreet nisl. Morbi volutpat dui vitae efficitur posuere. Pellentesque mi libero, dapibus ut tellus eu, volutpat viverra magna. Phasellus vitae erat porta, condimentum enim ac, luctus dui. Fusce dignissim, neque quis aliquet posuere, ante tortor lobortis eros, et facilisis dolor ipsum malesuada ante.</p>
        </div>
    )
}
export default Discription