import img1 from '../../assets/images/product/thunb-2.jpg';
import img2 from '../../assets/images/product/thunb-2.jpg';
import img3 from '../../assets/images/product/thunb-4.jpg';
import img4 from '../../assets/images/product/thunb-5.jpg';

export const ImageTableData = [
    {
        image: img1,
        inputvalue: '',
        colorvalue: '#cccccc',
        qvalue: '',
        qPrice: '',
    },
    // {
    //     image: img2,
    //     inputvalue: '',
    //     colorvalue: '#426531',
    //     qvalue: '',
    //     qPrice: '',
    // },
    // {
    //     image: img3,
    //     inputvalue: '',
    //     colorvalue: '#547681',
    //     qvalue: '',
    //     qPrice: ""
    // },
    // {
    //     image: img4,
    //     inputvalue: '',
    //     colorvalue: '#45df81',
    //     qvalue: '',
    //     qPrice: '',
    // }


]