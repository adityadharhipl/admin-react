import Avatar6 from '../../../assets/images//xs/avatar6.svg';
import Avatar1 from '../../../assets/images//xs/avatar1.svg';
import Avatar4 from '../../../assets/images//xs/avatar4.svg';
import Avatar5 from '../../../assets/images//xs/avatar5.svg';
import Avatar3 from '../../../assets/images//xs/avatar3.svg';
import Avatar7 from '../../../assets/images//xs/avatar7.svg';


export const ChatData=[
    {
        image:Avatar6,
        name:'Vanessa Knox',
        time:'10:45 AM',
        message:'There are many variations of passages'
    },
    {
        image:Avatar1,
        name:'Abigail Bell',
        time:'11:45 AM',
        message:'changed an issue from "In Progress" to'
    },
    {
        image:Avatar1,
        name:'Diane Blake',
        time:'12:45 AM',
        message:'It is a long established fact that a reader will be distracted'
    },
    {
        image:Avatar4,
        name:'Megan Dyer',
        time:'12:46 AM',
        message:'Contrary to popular belief'
    },
    {
        image:Avatar1,
        name:'Abigail Bell',
        time:'12:47 PM',
        message:'changed an issue from "In Progress" to'
    },
    {
        image:Avatar4,
        name:'Megan Dyer',
        time:'12:46 AM',
        message:'Contrary to popular belief'
    },
    {
        image:Avatar5,
        name:'Diane Blake',
        time:'12:48 PM',
        message:'making it over 2000 years old'
    },
    {
        image:Avatar3,
        name:'Vanessa Knox',
        time:'12:49 PM',
        message:'There are many variations of passages'
    },
    {
        image:Avatar7,
        name:'Donna Grant',
        time:'Thu',
        message:'Add Calander Event'
    },
    {
        image:Avatar1,
        name:'Diane Blake',
        time:'Wed',
        message:'It is a long established fact that a reader will be distracted'
    },
    {
        image:Avatar3,
        name:'Vanessa Knox',
        time:'13/10/2020',
        message:'There are many variations of passages'
    },
    {
        image:Avatar4,
        name:'Megan Dyer',
        time:'13/10/2020',
        message:'Contrary to popular belief'
    },
    {
        image:Avatar5,
        name:'Diane Blake',
        time:'22/10/2020',
        message:'making it over 2000 years old'
    },

]